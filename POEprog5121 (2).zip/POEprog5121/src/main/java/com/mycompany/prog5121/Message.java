/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121;

/**
 *
 * @author Student
 */
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Message {

    private final String messageID;
    private final String recipient;
    private final String message;
    private final int messageNumber;
    private final String messageHash;

    private static int totalMessages = 0;
    private static final List<Message> sentMessages =
            new ArrayList<>();

    public Message(String recipient, String message,
                   int messageNumber) {

        this.messageID = String.format("%010d",
                new Random().nextInt(1_000_000_000));
        this.recipient = recipient;
        this.message = message;
        this.messageNumber = messageNumber;
        this.messageHash = createMessageHash();
    }

    public boolean checkMessageID() {
        return messageID.length() == 10;
    }

    public String checkRecipientCell() {
        if (recipient != null
                && recipient.matches("^\\+27\\d{9}$")) {
            return "Cell phone number successfully captured.";
        }

        return "Cell phone number is incorrectly formatted or "
                + "does not contain an international code. "
                + "Please correct the number and try again.";
    }

    public boolean checkMessage() {
        return message != null
                && !message.trim().isEmpty()
                && message.length() <= 250;
    }

    private String createMessageHash() {
        String trimmed = message.trim();

        String[] words = trimmed.isEmpty()
                ? new String[0] : trimmed.split("\\s+");

        String firstWord = words.length == 0
                ? "" : words[0];

        String lastWord = words.length == 0
                ? "" : words[words.length - 1];

        return (messageID.substring(0, 2) + ":"
                + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();
    }

    public String SentMessage(String choice) {
        if (choice == null) {
            return "Invalid option.";
        }

        switch (choice.toLowerCase()) {
            case "send" -> {
                sentMessages.add(this);
                totalMessages++;
                return "Message successfully sent.";
            }

            case "discard" -> {
                return "Press 0 to delete the message.";
            }

            case "store" -> {
                try {
                    storeMessage();
                    return "Message successfully stored.";
                } catch (IOException e) {
                    return "Message could not be stored.";
                }
            }

            default -> {
                return "Invalid option.";
            }
        }
    }

    public String printMessages() {
        StringBuilder output = new StringBuilder();

        for (Message msg : sentMessages) {
            output.append("Message ID: ")
                    .append(msg.messageID)
                    .append("\nMessage Hash: ")
                    .append(msg.messageHash)
                    .append("\nRecipient: ")
                    .append(msg.recipient)
                    .append("\nMessage: ")
                    .append(msg.message)
                    .append("\n\n");
        }

        return output.length() == 0
                ? "No messages have been sent."
                : output.toString();
    }

    public int returnTotalMessages() {
        return totalMessages;
    }

    public void storeMessage() throws IOException {
        Path file = Path.of("messages.json");

        String object = "{"
                + "\"messageID\":\"" + escape(messageID) + "\","
                + "\"messageHash\":\"" + escape(messageHash) + "\","
                + "\"recipient\":\"" + escape(recipient) + "\","
                + "\"message\":\"" + escape(message) + "\""
                + "}";

        String existing = Files.exists(file)
                ? Files.readString(file).trim() : "";

        String updated;

        if (existing.isEmpty() || existing.equals("[]")) {
            updated = "[\n" + object + "\n]";
        } else if (existing.endsWith("]")) {
            updated = existing.substring(0, existing.length() - 1)
                    + ",\n" + object + "\n]";
        } else {
            throw new IOException("The JSON file is not valid.");
        }

        Files.writeString(file, updated,
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING);
    }

    private String escape(String value) {
        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }
}


    

