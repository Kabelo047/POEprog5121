/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121;

/**
 *
 * @author Student
 */
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Login login = new Login();

        // PART 1: Registration
        System.out.println("=== Registration ===");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        System.out.print("Enter SA cell number (+27XXXXXXXXX): ");
        String phone = input.nextLine();

        String result = login.registerUser(username, password, phone);
        System.out.println(result);

        if (!result.equals("User has been registered successfully.")) {
            input.close();
            return;
        }

        System.out.print("Enter first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter last name: ");
        String lastName = input.nextLine();

        // PART 1: Login
        System.out.println("\n=== Login ===");

        System.out.print("Username: ");
        String loginUsername = input.nextLine();

        System.out.print("Password: ");
        String loginPassword = input.nextLine();

        boolean loggedIn = login.loginUser(loginUsername, loginPassword);

        System.out.println(
                login.returnLoginStatus(loggedIn, firstName, lastName));

        if (!loggedIn) {
            input.close();
            return;
        }

        // PART 2: Messaging
        System.out.println("\nWelcome to QuickChat.");

        boolean running = true;
        int messageNumber = 0;
        int sentCount = 0;

        while (running) {

            System.out.println("\n=== QuickChat Menu ===");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");
            System.out.print("Choose an option: ");

            String option = input.nextLine();

            switch (option) {

                case "1":
                    System.out.print(
                            "How many messages would you like to send? ");

                    int numberOfMessages;

                    try {
                        numberOfMessages =
                                Integer.parseInt(input.nextLine());

                        if (numberOfMessages < 1) {
                            System.out.println(
                                    "Enter a number greater than zero.");
                            break;
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Please enter a valid number.");
                        break;
                    }

                    for (int i = 0; i < numberOfMessages; i++) {

                        System.out.println(
                                "\nPreparing message " + (i + 1));

                        System.out.print(
                                "Enter recipient number (+27XXXXXXXXX): ");
                        String recipient = input.nextLine();

                        System.out.print("Enter your message: ");
                        String text = input.nextLine();

                        // Validate the message before processing
                        if (text.trim().isEmpty() || text.length() >= 250) {
                            System.out.println(
                                    "Please enter a message containing "
                                    + "1 to 249 characters.");
                            i--;
                            continue;
                        }

                        Message msg = new Message(
                                recipient, text, ++messageNumber);

                        String phoneResult = msg.checkRecipientCell();
                        System.out.println(phoneResult);

                        if (!phoneResult.startsWith(
                                "Cell phone number successfully")) {
                            i--;
                            messageNumber--;
                            continue;
                        }

                        System.out.println(
                                "Message ID: " + msg.getMessageID());
                        System.out.println(
                                "Message Hash: " + msg.getMessageHash());

                        System.out.println("\nChoose an action:");
                        System.out.println("1. Send Message");
                        System.out.println("2. Discard Message");
                        System.out.println("3. Store Message");
                        System.out.print("Your choice: ");

                        String action = input.nextLine();

                        switch (action) {

                            case "1":
                                System.out.println(
                                        msg.SentMessage("send"));

                                sentCount++;

                                System.out.println("\nMessage details:");
                                System.out.println("Message ID: "
                                        + msg.getMessageID());
                                System.out.println("Message Hash: "
                                        + msg.getMessageHash());
                                System.out.println("Recipient: "
                                        + msg.getRecipient());
                                System.out.println("Message: "
                                        + msg.getMessage());
                                break;

                            case "2":
                                System.out.println(
                                        msg.SentMessage("discard"));
                                break;

                            case "3":
                                System.out.println(
                                        msg.SentMessage("store"));
                                break;

                            default:
                                System.out.println("Invalid option.");
                                i--;
                                messageNumber--;
                                break;
                        }
                    }
                    break;

                case "2":
                    System.out.println("Coming Soon.");
                    break;

                case "3":
                    System.out.println(
                            "Total messages sent: " + sentCount);
                    System.out.println(
                            "Thank you for using QuickChat.");
                    running = false;
                    break;

                default:
                    System.out.println(
                            "Invalid option. Please choose 1, 2 or 3.");
            }
        }

        input.close();
    }
}
