/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 *
 * @author Student
 */

public class MessageTest {

    @Test
    void testMessageIDIsValid() {
        Message message = new Message(
                "+27817894567",
                "Hello, how are you?",
                1
        );

        assertTrue(message.checkMessageID());
    }

    @Test
    void testRecipientNumberIsValid() {
        Message message = new Message(
                "+27817894567",
                "Hello",
                1
        );

        assertEquals(
                "Cell phone number successfully captured.",
                message.checkRecipientCell()
        );
    }

    @Test
    void testRecipientNumberIsInvalid() {
        Message message = new Message(
                "0812345678",
                "Hello",
                1
        );

        assertEquals(
                "Cell phone number is incorrectly formatted or "
                + "does not contain an international code. "
                + "Please correct the number and try again.",
                message.checkRecipientCell()
        );
    }

    @Test
    void testMessageLengthIsValid() {
        Message message = new Message(
                "+27817894567",
                "Hello, how are you?",
                1
        );

        assertTrue(message.checkMessage());
    }

    @Test
    void testMessageTooLong() {
        String longMessage = "A".repeat(251);

        Message message = new Message(
                "+27817894567",
                longMessage,
                1
        );

        assertFalse(message.checkMessage());
    }

    @Test
    void testMessageHashIsCreated() {
        Message message = new Message(
                "+27817894567",
                "Hi Mike, can you join us for dinner tonight?",
                1
        );

        assertNotNull(message.getMessageHash());
        assertFalse(message.getMessageHash().isEmpty());
    }

    @Test
    void testDiscardMessage() {
        Message message = new Message(
                "+27817894567",
                "This message will be discarded.",
                1
        );

        assertEquals(
                "Press 0 to delete the message.",
                message.SentMessage("discard")
        );
    }

    @Test
    void testSendMessage() {
        Message message = new Message(
                "+27817894567",
                "Hello, this is a test message.",
                1
        );

        assertEquals(
                "Message successfully sent.",
                message.SentMessage("send")
        );
    }

    @Test
    void testTotalMessagesSent() {
        int before = new Message(
                "+27817894567",
                "Counter test",
                1
        ).returnTotalMessages();

        Message message = new Message(
                "+27817894567",
                "Testing the message count.",
                2
        );

        message.SentMessage("send");

        assertEquals(
                before + 1,
                message.returnTotalMessages()
        );
    }
}
